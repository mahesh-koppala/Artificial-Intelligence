Name: Mahesh Koppala
ID: 1001764522

Code Structure:	Import Arguments. Initialize Combinations and truth value dictionary of 
given arguments. "Class BayesianNetwork" consists of functions to calculate probability (computeProbability()) and total probability (Total_prob())
Given probability values are stored in variables in "__init__"
Result is printed for the provided arguments

Execution:
python bnet.py [arguments]
python bnet.py query1 query2.. given observation1..
(You can only provide a maximum of 6 arguments)
Example: 
python bnet.py At Bf given Mt
python bnet.py Bt Af Mf Jt Et